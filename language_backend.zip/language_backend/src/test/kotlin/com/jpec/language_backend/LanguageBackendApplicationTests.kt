package com.jpec.language_backend

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class LanguageBackendApplicationTests {

	@Test
	fun contextLoads() {
	}

}

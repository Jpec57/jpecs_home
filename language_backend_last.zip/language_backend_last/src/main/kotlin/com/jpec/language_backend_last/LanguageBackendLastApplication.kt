package com.jpec.language_backend_last

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class LanguageBackendLastApplication

fun main(args: Array<String>) {
	runApplication<LanguageBackendLastApplication>(*args)
}

package com.jpec.language_backend_last

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class LanguageBackendLastApplicationTests {

	@Test
	fun contextLoads() {
	}

}
